# RALLY

Shared Rust playtest and simulation-validation infrastructure for the Games
Design series.

RALLY is the common substrate for deterministic runs, event traces, validation
reports, comparison reports, and evidence packets across repos such as AMAZE,
QUEST, HUNT, TIGRIS, and CERES. It should keep reusable mechanics here while
each consumer repo keeps its own creative or economic policy, Markdown
contracts, personas, and review language.

## First command

```powershell
cargo test
```

For the smallest operator-facing proof, run:

```powershell
cargo test proof_fixtures_record_pass_and_structured_failure
```

[`docs\proof-surface.md`](docs/proof-surface.md) explains the retained accepted
and structured-failure fixtures and the product-policy boundary.

For the six current source-level consumers, run:

```powershell
cargo test --test consumer_contracts
```

The [consumer compatibility contract](docs/consumer-compatibility.md) records
representative neutral compatibility canaries for AMAZE, QUEST, HUNT, TIGRIS,
BANISH, and CERES plus migration, deprecation, and rollback rules.

## Product thesis

Game-design repos need repeatable validation without flattening their media.
Escape rooms, D&D campaigns, puzzle hunts, and board games all have different
creative contracts, but they share a validation shape:

```text
SCENARIO -> SEEDED RUN -> EVENT LOG -> VALIDATION REPORT -> EVIDENCE PACKET
```

RALLY owns that shared shape. Repo-local adapters decide what a scene, beat,
player, puzzle, Parliament stake, or room mechanism means.

SCENARIUM compatibility and the exact neutral-type migration ledger are
documented in [`docs/scenarium-compatibility.md`](docs/scenarium-compatibility.md).

## Phase motif

RALLY phases use famous speed races as planning mnemonics:

1. **Cannonball Run** - foundation and first adoption plans.
2. **Mille Miglia** - AMAZE adapter extraction.
3. **Dakar Rally** - QUEST mechanics compatibility.
4. **24 Hours of Le Mans** - HUNT and TIGRIS endurance validation.

## Initial core

The first crate, `rally-core`, provides:

- deterministic seeded run primitives,
- deterministic dice primitives for reusable mechanical resolution,
- tabletop turn order, score track, and token-pool helpers,
- deterministic shuffle/draw piles, phase tracks, action budgets, and grid
  coordinates for board/card/table games,
- token conversion, market rows, area-control majority checks, and vote tallies,
- hidden-information zones and structured board-event JSONL rows,
- bounded sampling and percentage helpers for repeatable simulations,
- stable scenario/scene/beat references,
- JSONL event-log row output,
- validation findings and report status with neutral JSON output,
- comparison reports with neutral JSON output,
- packet manifest scaffolding with neutral JSON output,
- RUNE field-metadata contracts for the neutral simulation/report spine.

## First consumers

| Repo | Target use |
|---|---|
| AMAZE | Extract product-neutral seeded simulation, validation rows, and packet conventions from the Rust room harness. |
| QUEST | Gradually port deterministic dice, event logging, checkpoint validation, and mechanical beat validation from Python. |
| HUNT | Validate puzzle graphs, solver coverage, blind-test manifests, hint timing, and publish readiness. |
| TIGRIS | Validate Parliament stage completeness, axis/stake rows, seeded playthrough manifests, and corpus/rubric consistency. |
| CERES | Model real local-production economies and industries while using only RALLY's neutral run/report/evidence spine. |

## RUNE contracts

RALLY exposes a first RUNE descriptor collection for its neutral simulator and
validation evidence types:

```text
docs\rune\simulation_contracts.json
```

The collection covers `SimulationRun`, `ActorTrace`, `SimulationMetric`,
`ComparisonDelta`, `ValidationFinding`, and `ValidationReport`. It uses
RUNE field metadata for required status, units, sensitivity, examples,
stability, and aliases without moving HUNT, TIGRIS, or other product policy into
RALLY.

## Non-goals

- RALLY does not own escape-room, D&D, puzzle-hunt, board-game, or CERES
  economic policy.
- RALLY does not replace repo-local skills or review panels.
- RALLY does not require every game repo to rewrite all existing tools at once.
- RALLY does not publish private room, campaign, vendor, or playtest details.

## License

RALLY uses separate licenses for software and content. Source code,
executable scripts, tests, configuration, and ordinary software
documentation are MIT-licensed (copyright Gio Della-Libera). Original
non-software content is licensed CC BY-NC 4.0 (copyright Gio Della-Libera);
commercial use of that content requires separate written permission.
Third-party material remains under its own terms.
See [LICENSE](./LICENSE) for the complete notice.
