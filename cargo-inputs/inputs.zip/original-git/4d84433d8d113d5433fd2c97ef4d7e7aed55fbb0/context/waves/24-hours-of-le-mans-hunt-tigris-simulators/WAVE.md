# 24 Hours of Le Mans - HUNT/TIGRIS Simulators

## Status

Active.

## Goal

Prove RALLY can support long-running game-design validation without absorbing
game-specific policy. HUNT and TIGRIS get local Rust simulators; RALLY provides
seeded runs, actor traces, metrics, and validation rows.

## Scope

- Add product-neutral simulation primitives to `rally-core`.
- Add a TIGRIS board-game simulator pilot for Parliament.
- Add a HUNT puzzle-hunt simulator pilot for WAVELENGTH.
- Add batch/endurance telemetry so each pilot surfaces design risk, not only
  smoke-test success.
- Add TIGRIS rule-variant comparison so Parliament can test fixes for weak
  adoption pressure.
- Add HUNT variant comparison so WAVELENGTH can test fixes for P5/P6
  bottlenecks and target-window pressure.
- Standardize simulator variant output with RALLY comparison reports.
- Expand beyond the first pilots with HUNT Game Night multi-author simulation
  and TIGRIS UPSTAGE party-game robustness simulation.
- Promote second-pilot findings back into HUNT and TIGRIS product docs without
  moving scenario or rule policy into RALLY.
- Track adapter-owned policy explicitly so RALLY stays generic.

## Validation

```powershell
cd repos\games-design\rally
cargo test --quiet

cd ..\tigris\tools\tigris-sim
cargo test --quiet
cargo run --quiet -- --seed parliament-smoke
cargo run --quiet -- --seed parliament-smoke --runs 20 --players 4
cargo run --quiet -- --seed parliament-smoke --compare-variants --runs 20 --players 4
cargo run --quiet -- --game upstage --seed upstage-smoke --players 8 --compare-variants --runs 24

cd ..\..\hunt\tools\hunt-sim
cargo test --quiet
cargo run --quiet -- --seed wavelength-smoke
cargo run --quiet -- --seed wavelength-smoke --runs 12
cargo run --quiet -- --seed wavelength-smoke --compare-variants --runs 12
cargo run --quiet -- --scenario boardgames --seed game-night-smoke --compare-variants --runs 12
```
